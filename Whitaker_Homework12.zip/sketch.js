  var px = 50;
  var py = 50;
  var pdiameter = 50;
  var o1x = 600;
  var o1y = 100;
  var o1d = 70;
  var o2x = 300;
  var o2y = 300;
  var o2d = 137;
  var mousex = 0;
  var mousey = 0;
  
  function setup()
  {
    createCanvas(800,600);
  }

  function draw()
  {
    background(100,56,125);
    
    createObstacle1();
    
    createObstacle2();
    
    createPlayer();
    
    movePlayer();
    
    createExit();
    
    moveObstacles();
    
    youWin();
    
    mouseCircle();
  }

    function mousePressed() 
    {  
      mousex = mouseX;
      mousey = mouseY;
    }

    function mouseCircle()
    {
      fill(5,100,5);
      circle(mousex,mousey,35);
    }

    function createObstacle1()
    {
      fill(255,0,0);
      circle(o1x,o1y,o1d);
    }
    
    function createObstacle2()
    {
      fill(120,50,10);
      circle(o2x,o2y,o2d);
    }
    
    function createPlayer()
    {
      fill(0,0,255);
      circle(px,py,pdiameter);
      fill(0);
      textSize(16);
      text('Player',15,20);
    }
    
    function movePlayer()
    {
      if(keyIsDown(68))
      {
      px+=5;
      }
      else if(keyIsDown(65))
      {
      px-=5;
      }
      else if(keyIsDown(83))
      {
      py+=5;
      }
      else if(keyIsDown(87))
      {
      py-=5;
      }
    }
    
    function createExit()
    {
      fill(0,255,0);
      rect(700,400,100,200);
      fill(0)
      textSize(30)
      text('Exit',725,515)
    }
    
    function moveObstacles()
    {
      if(o1x <= 800)
      {
      o1x+=5;
      } 
      else
      {
      o1x=10;
      }
      if(o2y <= 600)
      {
      o2y+=5;
      }
      else
      {
      o2y=10;
      }     
    }
    
    function youWin()
    {
      if(px >= 700 && py >= 400)
      {
      textSize(60);
      fill(255,255,255);
      text('You win! Thanks for playing!',27,300);
      }
    }